# BriMor Labs Windows Live Response - GPS Modified
This is a version of the BriMor Labs Windows Live Response host forensics acquisition tool, with some small modifications made by GuidePoint DFIR for with Legacy systems (system versions < Windows 2008R2/Windows 7).  

# Execution
To run this software:
1. Download the provided `Windows_Live_Response-GPS.zip` file to the target host.  
2. Then, via RDP, extract the `Windows_Live_Response.zip` file.
3. Open a Command Prompt (`cmd.exe`) as Administrator.
4. Change directory to the Extracted `Windows_Live_Response` directory. (`cd C:\<path>\<to>\Windows_Live_Response`)
5. Execute the `Windows Live Response Collection.exe` binary.
6. A window, as shown below, will appear.  Choose the options highlighted by boxes 1 and 2 in the image below.

![Windows Live Response Options](./images/WLR_Options_Window.png?raw=true "Windows Live Response Options")

7. Watch the command prompt for script progress.  Once the script is completed, the message will appear there.
8. Open Windows Explorer, and navigate to the `Windows Live Response` directory, a new directory will be created beginning with the hostname of the current system, followed by the date and time. (ex. `<HOSTNAME>_20210405_1121`)
9. Zip up that directory and upload to the location specified by your GPS analyst.