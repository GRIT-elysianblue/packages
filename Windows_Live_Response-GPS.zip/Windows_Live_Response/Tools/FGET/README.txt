Note: This is a free HBGary utility that appears to have been removed from their site. 
It's hosted here only as a mirror, and will be removed if they ask us to. 